#ifndef FTEGRADE_H
#define FTEGRADE_H

enum class FTEGrade{
    A,B,C
};

#endif // FTEGRADE_H
